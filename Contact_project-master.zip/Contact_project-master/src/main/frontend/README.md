npm run build:ssr && npm run serve:ssr
